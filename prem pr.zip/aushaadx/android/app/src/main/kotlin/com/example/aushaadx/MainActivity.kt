package com.example.aushaadx

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
