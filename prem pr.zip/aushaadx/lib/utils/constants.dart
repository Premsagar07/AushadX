// 📁 lib/utils/constants.dart
import 'package:flutter/material.dart';

class AppColors {
  static const primary = Colors.teal;
  static const accent = Colors.tealAccent;
  static const background = Colors.white;
  static const text = Colors.black87;
}

class AppStrings {
  static const appName = 'AushadX';
  static const emergencyNumber = '108';
}

