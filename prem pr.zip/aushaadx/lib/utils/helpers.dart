// 📁 lib/utils/helpers.dart
class Helpers {
  static String formatDateTime(DateTime dt) {
    return "${dt.day}/${dt.month}/${dt.year} ${dt.hour}:${dt.minute.toString().padLeft(2, '0')}";
  }

  static bool isExpired(String expiry) {
    try {
      final parts = expiry.split("-");
      final expDate = DateTime(int.parse(parts[0]), int.parse(parts[1]));
      return expDate.isBefore(DateTime.now());
    } catch (_) {
      return false;
    }
  }
}
