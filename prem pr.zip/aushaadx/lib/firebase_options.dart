// lib/firebase_options.dart

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: "AIzaSyBUXuYnagGUvqAr9UauiukQtKB3F6mPLFI",
    appId: "1:304056348415:web:7463b355a541d4070b26ca",
    messagingSenderId: "304056348415",
    projectId: "aushadx-d4f17",
    authDomain: "aushadx-d4f17.firebaseapp.com",
    storageBucket: "aushadx-d4f17.appspot.com",
    measurementId: "G-8SWKSTVQFE",
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: "AIzaSyBUXuYnagGUvqAr9UauiukQtKB3F6mPLFI",
    appId: "1:304056348415:web:7463b355a541d4070b26ca",
    messagingSenderId: "304056348415",
    projectId: "aushadx-d4f17",
    storageBucket: "aushadx-d4f17.appspot.com",
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: "AIzaSyBUXuYnagGUvqAr9UauiukQtKB3F6mPLFI",
    appId: "1:304056348415:web:7463b355a541d4070b26ca",
    messagingSenderId: "304056348415",
    projectId: "aushadx-d4f17",
    storageBucket: "aushadx-d4f17.appspot.com",
    iosClientId: "YOUR_IOS_CLIENT_ID", // Optional: Only for real iOS setup
    iosBundleId: "com.example.aushadx", // Replace with actual iOS bundle ID if needed
  );
}
