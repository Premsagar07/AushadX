import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AddMedicineScreen extends StatefulWidget {
  @override
  _AddMedicineScreenState createState() => _AddMedicineScreenState();
}

class _AddMedicineScreenState extends State<AddMedicineScreen> {
  final _nameController = TextEditingController();
  final _priceController = TextEditingController();
  final _imageController = TextEditingController();

  void _addMedicine() async {
    final name = _nameController.text.trim();
    final price = _priceController.text.trim();
    final image = _imageController.text.trim();

    if (name.isEmpty || price.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Name and Price are required')),
      );
      return;
    }

    await FirebaseFirestore.instance.collection('medicines').add({
      'name': name,
      'price': price,
      'image': image.isNotEmpty ? image : null,
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Medicine added')),
    );

    _nameController.clear();
    _priceController.clear();
    _imageController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Add Medicine"), backgroundColor: Colors.teal),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: _nameController, decoration: InputDecoration(labelText: "Name")),
            TextField(controller: _priceController, decoration: InputDecoration(labelText: "Price")),
            TextField(controller: _imageController, decoration: InputDecoration(labelText: "Image URL (optional)")),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _addMedicine,
              child: Text("Add Medicine"),
              style: ElevatedButton.styleFrom(minimumSize: Size.fromHeight(50), backgroundColor: Colors.teal),
            )
          ],
        ),
      ),
    );
  }
}
