import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class InventoryScreen extends StatefulWidget {
  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  // Sample medicine list (can be replaced with a database or storage later)
  List<Map<String, dynamic>> medicines = [
    {
      'name': 'Paracetamol',
      'quantity': 10,
      'expiry': '12/2025',
    },
    {
      'name': 'Aspirin',
      'quantity': 2,
      'expiry': '03/2026',
    },
    {
      'name': 'Cough Syrup',
      'quantity': 1,
      'expiry': '09/2024',
    },
  ];

  // Utility: Check if medicine is expired
  bool isExpired(String expiryDate) {
    final now = DateTime.now();
    final parts = expiryDate.split('/');
    final expiry = DateTime(int.parse(parts[1]), int.parse(parts[0]) + 1);
    return expiry.isBefore(now);
  }

  // Show dialog to add new medicine
  void _showAddMedicineDialog() {
    final nameController = TextEditingController();
    final quantityController = TextEditingController();
    final expiryController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Add Medicine"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(labelText: "Medicine Name"),
            ),
            TextField(
              controller: quantityController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Quantity"),
            ),
            TextField(
              controller: expiryController,
              decoration: InputDecoration(
                labelText: "Expiry (MM/YYYY)",
                hintText: "e.g., 09/2025",
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
            onPressed: () {
              if (nameController.text.isNotEmpty &&
                  quantityController.text.isNotEmpty &&
                  expiryController.text.isNotEmpty) {
                setState(() {
                  medicines.add({
                    'name': nameController.text,
                    'quantity': int.tryParse(quantityController.text) ?? 0,
                    'expiry': expiryController.text,
                  });
                });
                Navigator.pop(context);
              }
            },
            child: Text("Add"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Medicine Inventory'),
        backgroundColor: Colors.teal,
        centerTitle: true,
      ),
      body: medicines.isEmpty
          ? const Center(
        child: Text(
          'No medicines in inventory.',
          style: TextStyle(fontSize: 16),
        ),
      )
          : ListView.builder(
        itemCount: medicines.length,
        padding: const EdgeInsets.all(16),
        itemBuilder: (context, index) {
          final med = medicines[index];
          final expired = isExpired(med['expiry']);
          final lowStock = med['quantity'] < 3;

          return Card(
            margin: const EdgeInsets.symmetric(vertical: 8),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            elevation: 4,
            child: ListTile(
              leading: Icon(
                Icons.medication_liquid,
                color: expired ? Colors.grey : Colors.teal,
                size: 32,
              ),
              title: Text(
                med['name'],
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: expired ? Colors.grey : Colors.black,
                ),
              ),
              subtitle: Text(
                'Expiry: ${med['expiry']}',
                style: TextStyle(
                  color: expired ? Colors.red : Colors.black54,
                ),
              ),
              trailing: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'x${med['quantity']}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: lowStock ? Colors.orange : Colors.teal,
                    ),
                  ),
                  if (expired)
                    const Text(
                      "Expired",
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.red,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  else if (lowStock)
                    const Text(
                      "Low Stock",
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.orange,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddMedicineDialog,
        child: const Icon(Icons.add),
        backgroundColor: Colors.teal,
        tooltip: 'Add Medicine',
      ),
    );
  }
}
