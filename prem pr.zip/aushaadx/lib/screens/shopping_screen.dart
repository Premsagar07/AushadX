import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';

import '../models/cart_item.dart';
import '../providers/cart_provider.dart';

class ShoppingScreen extends StatefulWidget {
  @override
  _ShoppingScreenState createState() => _ShoppingScreenState();
}

class _ShoppingScreenState extends State<ShoppingScreen> {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();
    seedSampleMedicines();
  }

  // 🔰 Seed sample medicines only if Firestore is empty
  Future<void> seedSampleMedicines() async {
    final collection = firestore.collection('medicines');
    final snapshot = await collection.get();

    if (snapshot.docs.isEmpty) {
      await collection.add({
        'name': 'Paracetamol',
        'price': '₹25',
        'image': '',
      });
      await collection.add({
        'name': 'Amoxicillin',
        'price': '₹40',
        'image': '',
      });
      await collection.add({
        'name': 'Ibuprofen',
        'price': '₹30',
        'image': '',
      });
      await collection.add({
        'name': 'Cough Syrup',
        'price': '₹60',
        'image': '',
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Medicine Shop"),
        backgroundColor: Colors.teal,
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.pushNamed(context, '/cart');
            },
          )
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: firestore.collection('medicines').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("No medicines available."));
          }

          final medicines = snapshot.data!.docs;

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: medicines.length,
            itemBuilder: (context, index) {
              final med = medicines[index];
              final medName = med['name'] ?? 'Unknown';
              final medPrice = med['price'] ?? '₹0';
              final imageUrl = med['image'] ?? '';

              return Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 4,
                margin: const EdgeInsets.symmetric(vertical: 8),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.teal[100],
                    radius: 25,
                    child: imageUrl.isNotEmpty
                        ? ClipRRect(
                      borderRadius: BorderRadius.circular(30),
                      child: Image.network(
                        imageUrl,
                        height: 30,
                        width: 30,
                        fit: BoxFit.cover,
                      ),
                    )
                        : const Text("💊", style: TextStyle(fontSize: 20)),
                  ),
                  title: Text(
                    medName,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  subtitle: Text("Price: $medPrice"),
                  trailing: ElevatedButton(
                    onPressed: () {
                      final cart = Provider.of<CartProvider>(context, listen: false);
                      cart.addItem(CartItem(name: medName, price: medPrice));
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('$medName added to cart')),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text("Add"),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
