import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/reminder_model.dart';
import '../services/reminder_storage_service.dart';
import 'add_reminder_screen.dart';

class RemindersScreen extends StatefulWidget {
  @override
  _RemindersScreenState createState() => _RemindersScreenState();
}

class _RemindersScreenState extends State<RemindersScreen> {
  List<Reminder> reminders = [];

  @override
  void initState() {
    super.initState();
    loadReminders();
  }

  // Load reminders from local storage
  void loadReminders() async {
    reminders = await ReminderStorageService.loadReminders();

    // If no reminders found, show sample examples
    if (reminders.isEmpty) {
      reminders = [
        Reminder(
          medicine: "Paracetamol",
          description: "For fever and headache",
          time: DateTime.now().add(Duration(minutes: 1)),
        ),
        Reminder(
          medicine: "Amoxicillin",
          description: "Antibiotic - after lunch",
          time: DateTime.now().add(Duration(minutes: 2)),
        ),
        Reminder(
          medicine: "Vitamin D",
          description: "Once daily in morning",
          time: DateTime.now().add(Duration(minutes: 3)),
        ),
      ];

      await ReminderStorageService.saveReminders(reminders);
    }

    setState(() {});
  }



  // Add a new reminder and save
  void addReminder(Reminder reminder) async {
    reminders.add(reminder);
    await ReminderStorageService.saveReminders(reminders);
    setState(() {});
  }

  // Delete a reminder and save
  void deleteReminder(int index) async {
    reminders.removeAt(index);
    await ReminderStorageService.saveReminders(reminders);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Medicine Reminders"),
        backgroundColor: Colors.teal,
      ),
      body: reminders.isEmpty
          ? Center(child: Text("No reminders yet. Tap + to add one."))
          : ListView.builder(
        itemCount: reminders.length,
        itemBuilder: (context, index) {
          final r = reminders[index];
          return Card(
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: ListTile(
              title: Text(r.medicine),
              subtitle: Text("${r.description}\nTime: ${DateFormat.jm().format(r.time)}"),
              isThreeLine: true,
              trailing: IconButton(
                icon: Icon(Icons.delete, color: Colors.red),
                onPressed: () => deleteReminder(index),
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.teal,
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddReminderScreen()),
          );
          if (result is Reminder) addReminder(result);
        },
        child: Icon(Icons.add),
      ),

    );
  }
}
