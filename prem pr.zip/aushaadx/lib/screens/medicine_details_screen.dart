// 📁 lib/screens/medicine_details_screen.dart
import 'package:flutter/material.dart';

class MedicineDetailsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text("Medicine Details Screen"),
      ),
    );
  }
}
