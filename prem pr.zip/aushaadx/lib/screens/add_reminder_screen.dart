import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/notification_service.dart';
import '../models/reminder_model.dart';

class AddReminderScreen extends StatefulWidget {
  @override
  _AddReminderScreenState createState() => _AddReminderScreenState();
}

class _AddReminderScreenState extends State<AddReminderScreen> {
  // Controllers to hold the input for medicine name and description
  final TextEditingController nameController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();

  // Default time set to current time
  TimeOfDay selectedTime = TimeOfDay.now();

  // Function to show the time picker dialog and update selected time
  Future<void> pickTime(BuildContext context) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: selectedTime,
    );
    if (picked != null) {
      setState(() {
        selectedTime = picked;
      });
    }
  }

  // Schedules the reminder and notification
  void scheduleReminder() {
    final now = DateTime.now();

    // Constructs full DateTime from current date and selected time
    final scheduledDateTime = DateTime(
      now.year,
      now.month,
      now.day,
      selectedTime.hour,
      selectedTime.minute,
    );

    final medicineName = nameController.text.trim();
    final description = descriptionController.text.trim();

    // Guard clause if medicine name is empty
    if (medicineName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please enter a medicine name")),
      );
      return;
    }

    // Call to NotificationService to schedule the local notification
    NotificationService.scheduleNotification(
      id: scheduledDateTime.millisecondsSinceEpoch ~/ 1000,
      title: "Time to take $medicineName",
      body: description.isEmpty ? "Take your medicine!" : description,
      scheduledTime: scheduledDateTime,
    );

    // Creates the Reminder model object to pass back
    final reminder = Reminder(
      medicine: medicineName,
      description: description,
      time: scheduledDateTime,
    );

    // Pops the screen and passes back the created reminder
    Navigator.pop(context, reminder);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add Reminder"),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Text input for medicine name
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: "Medicine Name"),
            ),
            const SizedBox(height: 12),

            // Optional description field
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(labelText: "Description (optional)"),
            ),
            const SizedBox(height: 20),

            // Row showing selected time and button to pick a new time
            Row(
              children: [
                Text("Reminder Time: ${selectedTime.format(context)}"),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () => pickTime(context),
                  child: const Text("Pick Time"),
                ),
              ],
            ),
            const Spacer(),

            // Button to schedule the reminder
            ElevatedButton(
              onPressed: scheduleReminder,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                minimumSize: const Size.fromHeight(50),
              ),
              child: const Text("Set Reminder"),
            ),
          ],
        ),
      ),
    );
  }
}
