// 📁 lib/providers/cart_provider.dart
import 'package:flutter/material.dart';
import '../models/cart_item.dart';

class CartProvider with ChangeNotifier {
  final List<CartItem> _items = [];

  List<CartItem> get items => _items;

  void addItem(CartItem item) {
    final index = _items.indexWhere((e) => e.name == item.name);
    if (index != -1) {
      _items[index] = CartItem(
        name: item.name,
        price: item.price,
        quantity: _items[index].quantity + 1,
      );
    } else {
      _items.add(item);
    }
    notifyListeners();
  }

  void removeItem(CartItem item) {
    _items.remove(item);
    notifyListeners();
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }

  double get total => _items.fold(0, (sum, item) {
    return sum + int.parse(item.price.replaceAll('₹', '')) * item.quantity;
  });
}
