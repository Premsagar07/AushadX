// 📁 lib/models/reminder.dart
class Reminder {
  final String id;
  final String medicineId;
  final DateTime time;
  final bool isRecurring;

  Reminder({
    required this.id,
    required this.medicineId,
    required this.time,
    required this.isRecurring,
  });
}
