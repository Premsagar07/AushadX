// 📁 lib/models/cart_item.dart
class CartItem {
  final String name;
  final String price;
  final int quantity;

  CartItem({required this.name, required this.price, this.quantity = 1});
}
