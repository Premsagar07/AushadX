class Reminder {
  final String medicine;
  final String description;
  final DateTime time;

  Reminder({
    required this.medicine,
    required this.description,
    required this.time,
  });

  Map<String, dynamic> toJson() => {
    'medicine': medicine,
    'description': description,
    'time': time.toIso8601String(),
  };

  static Reminder fromJson(Map<String, dynamic> json) => Reminder(
    medicine: json['medicine'],
    description: json['description'],
    time: DateTime.parse(json['time']),
  );
}
