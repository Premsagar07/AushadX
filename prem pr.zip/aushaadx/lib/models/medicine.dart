// 📁 lib/models/medicine.dart
class Medicine {
  final String id;
  final String name;
  final String description;
  final String expiry;
  final int quantity;
  final String dosage;
  final String image;
  final String category;
  final String activeIngredient;
  final String strength;
  final String manufacturer;

  Medicine({
    required this.id,
    required this.name,
    required this.description,
    required this.expiry,
    required this.quantity,
    required this.dosage,
    required this.image,
    required this.category,
    required this.activeIngredient,
    required this.strength,
    required this.manufacturer,
  });
}
