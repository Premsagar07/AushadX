// 📁 lib/services/database_service.dart
import '../models/medicine.dart';

class DatabaseService {
  Future<List<Medicine>> fetchMedicines() async {
    // Fetch medicines from DB or API
    return [];
  }

  Future<void> addMedicine(Medicine medicine) async {
    // Save medicine
  }

  Future<void> updateMedicine(Medicine medicine) async {
    // Update medicine
  }

  Future<void> deleteMedicine(String id) async {
    // Delete medicine by id
  }
}
