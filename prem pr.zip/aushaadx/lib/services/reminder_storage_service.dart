import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/reminder_model.dart';

class ReminderStorageService {
  static const _key = 'reminders';

  static Future<void> saveReminders(List<Reminder> reminders) async {
    final prefs = await SharedPreferences.getInstance();
    final data = reminders.map((r) => jsonEncode(r.toJson())).toList();
    await prefs.setStringList(_key, data);
  }

  static Future<List<Reminder>> loadReminders() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getStringList(_key) ?? [];
    return data.map((e) => Reminder.fromJson(jsonDecode(e))).toList();
  }
}
