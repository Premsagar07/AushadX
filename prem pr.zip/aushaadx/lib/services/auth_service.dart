// 📁 lib/services/auth_service.dart
class AuthService {
  Future<bool> login(String email, String password) async {
    // Add authentication logic here (e.g., FirebaseAuth)
    return email == "user@example.com" && password == "password123";
  }

  Future<void> logout() async {
    // Add logout logic
  }

  Future<bool> register(String email, String password) async {
    // Add registration logic
    return true;
  }
}
