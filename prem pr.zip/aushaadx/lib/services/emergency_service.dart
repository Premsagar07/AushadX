// 📁 lib/services/emergency_service.dart
import 'package:url_launcher/url_launcher.dart';

class EmergencyService {
  Future<void> callEmergency(String number) async {
    final Uri phoneUri = Uri(scheme: 'tel', path: number);
    if (await canLaunchUrl(phoneUri)) {
      await launchUrl(phoneUri);
    } else {
      throw 'Could not launch emergency number';
    }
  }
}
